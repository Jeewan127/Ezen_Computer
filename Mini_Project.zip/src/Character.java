
public interface Character {
	public int attack();
	public int skillAttack();
	public void printHp(int hp);
	public int hpMinus(int attackPoint);
	public void printInfo();
	public void printMp();
	public void printName();
}
